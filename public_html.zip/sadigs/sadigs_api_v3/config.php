<?php
// sadigs_api_v3/config.php

// PENTING: Ganti nilai-nilai placeholder berikut dengan kredensial database Hostinger Anda.
define('DB_SERVER', 'localhost'); // Ganti jika berbeda
define('DB_USERNAME', 'db_user_hostinger'); // Ganti dengan username DB Anda
define('DB_PASSWORD', 'db_password_hostinger'); // Ganti dengan password DB Anda
define('DB_NAME', 'nama_database_anda'); // Ganti dengan nama DB Anda

$config = [
    'app_id' => 'SADIGS_V3',
];

/**
 * Membuat dan mengembalikan koneksi database MySQL.
 * @return mysqli|false Objek koneksi atau false jika gagal.
 */
function connectDatabase() {
    // Membuat koneksi
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    
    // Memeriksa koneksi
    if ($conn->connect_error) {
        // Log error koneksi untuk debugging di server
        error_log("Koneksi database gagal: " . $conn->connect_error);
        return false;
    }
    
    // Mengatur charset ke utf8mb4 untuk dukungan emoji dan karakter khusus
    $conn->set_charset("utf8mb4");
    
    return $conn;
}

// Catatan: Dalam aplikasi nyata, inisialisasi sesi dan otentikasi akan dilakukan di sini
// atau di file 'session_check.php' yang terpisah.
?>