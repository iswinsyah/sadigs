<?php
// =================================================================
// SADIGS 3.0: KONEKSI DATABASE (PDO)
// File ini HARUS ada di folder API.
// =================================================================

// PASTIKAN SEMUA KONSTANTA DI BAWAH INI SESUAI 100% DENGAN INFO DI HPANEL ANDA!
define('DB_HOST', 'localhost');
define('DB_USER', 'u829486010_sadigsmysql'); 
define('DB_PASS', 'Khilafet@1924'); 
define('DB_NAME', 'u829486010_sadigsdatabase'); 

function getDBConnection() {
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    
    $options = array(
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,     
        PDO::ATTR_EMULATE_PREPARES   => false                
    );
    
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (\PDOException $e) {
        // Ini akan menghentikan eksekusi dan mengirim error 500 yang jelas
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(array(
            'success' => false, 
            'message' => 'Koneksi database gagal total.'
        ));
        exit;
    }
}

function sendJSONResponse($data, $statusCode = 200) {
    // Fungsi ini dipanggil dari file API setelah require_once db_connect.php
    header('Content-Type: application/json');
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}