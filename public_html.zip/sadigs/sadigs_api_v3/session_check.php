<?php
// --- KODE DEBUG DARI HOSTINGER START (Wajib Ada di semua API) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', $_SERVER['DOCUMENT_ROOT'] . '/php_error.log'); 
error_reporting(E_ALL);
// --- KODE DEBUG DARI HOSTINGER END ---

// FUNGSI UTILITY: Mengirim Respons JSON
function sendJSONResponse($data, $statusCode = 200) {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    header('Content-Type: application/json');
    http_response_code($statusCode);
    echo json_encode($data);
    exit;
}

// FUNGSI KONEKSI DATABASE (Terintegrasi)
function getDBConnection() {
    // PASTIKAN SEMUA KONSTANTA DI BAWAH INI SESUAI 100% DENGAN INFO DI HPANEL ANDA!
    define('DB_HOST', 'localhost'); 
    define('DB_USER', 'u829486010_sadigsmysql'); 
    define('DB_PASS', 'Khilafet@1924'); 
    define('DB_NAME', 'u829486010_sadigsdatabase'); 
    
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    
    $options = array(
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, 
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,     
        PDO::ATTR_EMULATE_PREPARES   => false                
    );
    
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (\PDOException $e) {
        // Jika koneksi gagal, catat ke log dan kirim respons error generik
        error_log("KONEKSI DATABASE GAGAL. DETAIL ERROR (PDO): " . $e->getMessage()); 
        sendJSONResponse(array('success' => false, 'message' => 'Kesalahan database saat validasi sesi.'), 500);
        exit;
    }
}


if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
date_default_timezone_set('Asia/Jakarta');

// Logika di bawah ini tidak memerlukan koneksi DB, hanya cek sesi yang sudah dibuat saat login
if (isset($_SESSION['user_id'], $_SESSION['username'], $_SESSION['roles']) && !empty($_SESSION['roles'])) {
    
    // Sesi valid, kirimkan data ke dashboard.html
    sendJSONResponse(array(
        'success' => true,
        'username' => $_SESSION['username'],
        'roles' => $_SESSION['roles'] 
    ));
    
} else {
    // Sesi tidak valid atau telah berakhir
    sendJSONResponse(array('success' => false, 'message' => 'Sesi berakhir atau tidak valid.'), 401);
}