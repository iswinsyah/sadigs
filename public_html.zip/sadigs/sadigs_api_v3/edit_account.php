<?php
// sadigs_api_v3/edit_account.php
// Endpoint untuk memperbarui data profil pengguna.

// Mengatur header agar respons selalu berupa JSON
header('Content-Type: application/json');

// Memuat file konfigurasi database
require_once 'config.php';

// Fungsi untuk mengirim respons JSON
function sendResponse($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// Hanya mengizinkan metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse('error', 'Metode tidak diizinkan. Gunakan POST.');
}

// Mendapatkan koneksi database
$conn = connectDatabase();
if (!$conn) {
    sendResponse('error', 'Gagal terhubung ke database.');
}

// --- Validasi Input Wajib ---
// user_id diperlukan untuk mengidentifikasi akun yang akan diubah
if (!isset($_POST['user_id']) || empty($_POST['user_id'])) {
    sendResponse('error', 'ID pengguna (user_id) wajib disertakan.');
}

$user_id = $_POST['user_id'];

// Data yang dapat diubah (ambil dari body POST)
$full_name = $_POST['full_name'] ?? null;
$bio = $_POST['bio'] ?? null;
$email = $_POST['email'] ?? null; // Hati-hati mengubah email, mungkin perlu verifikasi ulang

// Pastikan setidaknya satu field yang valid untuk diubah telah dikirim
if (is_null($full_name) && is_null($bio) && is_null($email)) {
    sendResponse('error', 'Tidak ada data yang valid untuk diperbarui. Sertakan full_name, bio, atau email.');
}

// Persiapan untuk membangun query UPDATE
$updates = [];
$types = '';
$params = [];

// 1. Full Name
if (!is_null($full_name)) {
    $updates[] = "full_name = ?";
    $types .= 's';
    $params[] = $full_name;
}

// 2. Bio
if (!is_null($bio)) {
    $updates[] = "bio = ?";
    $types .= 's';
    $params[] = $bio;
}

// 3. Email (Jika email disediakan, lakukan validasi dasar)
if (!is_null($email)) {
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        sendResponse('error', 'Format email tidak valid.');
    }
    // Cek apakah email sudah digunakan oleh pengguna lain (kecuali diri sendiri)
    $check_sql = "SELECT id FROM users WHERE email = ? AND id != ?";
    $check_stmt = $conn->prepare($check_sql);
    
    // Tentukan jenis user_id ('i' untuk integer, 's' untuk string)
    $id_type = is_numeric($user_id) ? 'i' : 's';

    $check_stmt->bind_param("s" . $id_type, $email, $user_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows > 0) {
        $check_stmt->close();
        sendResponse('error', 'Email sudah digunakan oleh akun lain.');
    }
    $check_stmt->close();

    $updates[] = "email = ?";
    $types .= 's';
    $params[] = $email;
}

// Tambahkan user_id ke parameter akhir untuk klausa WHERE
$params[] = $user_id;
// Tambahkan tipe untuk user_id di akhir
$types .= is_numeric($user_id) ? 'i' : 's';


// --- Eksekusi Query Update ---
if (count($updates) > 0) {
    $set_clause = implode(', ', $updates);
    $sql = "UPDATE users SET $set_clause, updated_at = NOW() WHERE id = ?";
    
    try {
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
            throw new Exception("Gagal menyiapkan statement: " . $conn->error);
        }

        // Bind parameter secara dinamis
        // Catatan: array_unshift() tidak berfungsi dengan bind_param by reference.
        // Solusi: gunakan call_user_func_array untuk mem-bind parameter array
        
        $bind_params = array();
        $bind_params[] = $types;
        foreach($params as $key => &$value) {
            $bind_params[] = &$value;
        }

        call_user_func_array(array($stmt, 'bind_param'), $bind_params);
        
        if (!$stmt->execute()) {
            throw new Exception("Gagal mengeksekusi update: " . $stmt->error);
        }

        if ($stmt->affected_rows > 0) {
            sendResponse('success', 'Akun berhasil diperbarui.', ['user_id' => $user_id, 'updated_fields' => array_keys(array_filter(['full_name' => $full_name, 'bio' => $bio, 'email' => $email]))]);
        } else {
            // Ini bisa berarti data yang dikirim sama dengan data yang sudah ada, atau user_id tidak ditemukan
            sendResponse('info', 'Tidak ada perubahan yang dilakukan atau ID pengguna tidak ditemukan.', ['user_id' => $user_id]);
        }
        
        $stmt->close();
        
    } catch (Exception $e) {
        error_log("Error di edit_account.php: " . $e->getMessage());
        sendResponse('error', 'Terjadi kesalahan pada server saat memperbarui data.', ['debug' => $e->getMessage()]);
    }
} else {
    // Seharusnya tidak tercapai karena sudah divalidasi di awal, tapi sebagai fallback
    sendResponse('error', 'Tidak ada data yang valid untuk diperbarui.');
}

$conn->close();
?>