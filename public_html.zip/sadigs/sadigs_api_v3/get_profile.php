<?php
// sadigs_api_v3/get_profile.php
// Endpoint untuk mengambil data profil pengguna berdasarkan user_id.

// Mengatur header agar respons selalu berupa JSON
header('Content-Type: application/json');

// Memuat file konfigurasi database
require_once 'config.php';

// Fungsi untuk mengirim respons JSON
function sendResponse($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit();
}

// Hanya mengizinkan metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendResponse('error', 'Metode tidak diizinkan. Gunakan POST.');
}

// Mendapatkan koneksi database
$conn = connectDatabase();
if (!$conn) {
    sendResponse('error', 'Gagal terhubung ke database.');
}

// Asumsi: user_id dikirim melalui body POST
// Dalam aplikasi nyata, user_id harus diverifikasi melalui token sesi atau JWT
if (!isset($_POST['user_id']) || empty($_POST['user_id'])) {
    sendResponse('error', 'ID pengguna (user_id) diperlukan.');
}

$user_id = $_POST['user_id'];

try {
    // Query untuk mengambil detail profil pengguna
    // PERHATIAN: Ganti nama tabel dan kolom sesuai dengan skema database Anda.
    $sql = "SELECT id, username, email, full_name, bio, created_at FROM users WHERE id = ?";
    
    // Menggunakan prepared statement untuk mencegah SQL Injection
    $stmt = $conn->prepare($sql);
    
    // Memastikan persiapan statement berhasil
    if (!$stmt) {
        throw new Exception("Gagal menyiapkan statement: " . $conn->error);
    }
    
    // Bind parameter (s = string, i = integer, dll. Kita asumsikan id adalah integer)
    // Jika 'id' adalah string/UUID, gunakan 's'
    if (!is_numeric($user_id)) {
        // Jika user_id bukan numerik, perlakukan sebagai string
        $stmt->bind_param("s", $user_id);
    } else {
        // Jika user_id numerik, perlakukan sebagai integer
        $user_id = (int)$user_id;
        $stmt->bind_param("i", $user_id);
    }
    
    // Eksekusi statement
    if (!$stmt->execute()) {
        throw new Exception("Gagal mengeksekusi query: " . $stmt->error);
    }
    
    // Ambil hasil
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Data pengguna ditemukan
        $profile = $result->fetch_assoc();
        
        // Hapus data sensitif sebelum dikirim (misalnya: password, jika ada)
        unset($profile['password']); 
        
        sendResponse('success', 'Data profil berhasil diambil.', $profile);
    } else {
        // Pengguna tidak ditemukan
        sendResponse('error', 'Pengguna dengan ID tersebut tidak ditemukan.', ['user_id' => $user_id]);
    }

    // Tutup statement
    $stmt->close();

} catch (Exception $e) {
    // Tangani exception dan kirim respons error
    error_log("Error di get_profile.php: " . $e->getMessage());
    sendResponse('error', 'Terjadi kesalahan pada server.', ['debug' => $e->getMessage()]);
}

// Tutup koneksi database
$conn->close();

?>